package com.project.POO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(GEventApplication.class, args);
	}

}
